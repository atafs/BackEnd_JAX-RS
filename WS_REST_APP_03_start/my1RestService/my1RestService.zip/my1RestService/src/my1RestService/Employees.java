package my1RestService;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("employees")
public class Employees {
	
	@GET
	public String getEmployeeNames() {
		return "Americo, Ana";
	}

}
